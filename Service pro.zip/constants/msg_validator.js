const validator_messages = {
    notNull: "Not allow null-s",
    notEmpty: "jo 0 karaktere"
}