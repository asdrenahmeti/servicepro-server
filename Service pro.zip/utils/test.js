/*
Punet e perfunduara
Modelet - krejt lidhjet e perfunduara
Ads - prej adminit


*/